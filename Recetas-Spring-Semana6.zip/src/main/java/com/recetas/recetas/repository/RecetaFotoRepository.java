package com.recetas.recetas.repository;

import com.recetas.recetas.model.RecetaFoto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface RecetaFotoRepository extends JpaRepository<RecetaFoto, Long> {
    List<RecetaFoto> findByRecetaIdOrderByFechaSubidaDesc(Long recetaId);
    Optional<RecetaFoto> findByRecetaIdAndEsPrincipalTrue(Long recetaId);
}

